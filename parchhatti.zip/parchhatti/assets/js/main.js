/**
 * Parchhatti Theme — Main JS
 */
(function () {
  'use strict';

  /* ── Mobile Menu Toggle ─────────────────────────────────────────── */
  const toggle = document.getElementById('menu-toggle');
  const nav    = document.getElementById('site-navigation');

  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      const isOpen = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');

      // Animate hamburger → X
      const spans = toggle.querySelectorAll('span');
      if (isOpen) {
        spans[0].style.transform = 'translateY(6.5px) rotate(45deg)';
        spans[1].style.opacity   = '0';
        spans[2].style.transform = 'translateY(-6.5px) rotate(-45deg)';
      } else {
        spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
      }
    });

    // Close on outside click
    document.addEventListener('click', function (e) {
      if (!nav.contains(e.target) && !toggle.contains(e.target)) {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.querySelectorAll('span').forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
      }
    });
  }

  /* ── Sticky Header Shadow ───────────────────────────────────────── */
  const header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.style.boxShadow = window.scrollY > 40
        ? '0 4px 30px rgba(201,168,76,0.15)'
        : '0 2px 20px rgba(201,168,76,0.08)';
    }, { passive: true });
  }

  /* ── Ticker Duplicate (ensure seamless loop) ────────────────────── */
  const ticker = document.getElementById('ticker-track');
  if (ticker) {
    // Clone the ticker content for seamless looping
    const clone = ticker.cloneNode(true);
    ticker.parentNode.appendChild(clone);
  }

  /* ── Fade-In on Scroll ──────────────────────────────────────────── */
  if ('IntersectionObserver' in window) {
    const items = document.querySelectorAll('.article-card, .home-section .section-header');

    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity    = '1';
          entry.target.style.transform  = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    items.forEach(function (item) {
      item.style.opacity   = '0';
      item.style.transform = 'translateY(20px)';
      item.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      observer.observe(item);
    });
  }

  /* ── Smooth Scroll for Anchor Links ────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ── Search Toggle ───────────────────────────────────────────────── */
  const searchIcon = document.querySelector('.header-icon[aria-label="Search"]');
  if (searchIcon) {
    searchIcon.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href && href.endsWith('?s=')) {
        e.preventDefault();
        const query = prompt('Search Parchhatti…');
        if (query && query.trim()) {
          window.location.href = href + encodeURIComponent(query.trim());
        }
      }
    });
  }

})();
